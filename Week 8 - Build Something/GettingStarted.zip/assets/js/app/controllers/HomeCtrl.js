app.controller('HomeCtrl', ['$scope', function($scope) {
    // Add functionality for home page here
}]);
